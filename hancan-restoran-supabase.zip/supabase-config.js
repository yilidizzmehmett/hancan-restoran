// Buraya Supabase Proje URL'si ve Publishable key yazılır.
// Secret veya service_role anahtarını asla kullanma.
window.HANCAN_SUPABASE_URL = "SUPABASE_PROJE_URL_BURAYA";
window.HANCAN_SUPABASE_PUBLISHABLE_KEY = "SB_PUBLISHABLE_ANAHTAR_BURAYA";
